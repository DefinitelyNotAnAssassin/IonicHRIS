"use client"

import {
  IonContent,
  IonHeader,
  IonItem,
  IonLabel,
  IonList,
  IonMenu,
  IonMenuToggle,
  IonTitle,
  IonToolbar,
} from "@ionic/react"
import { useHistory } from "react-router-dom"
import { useAuth } from "@/hooks/use-auth"

export default function SideMenu() {
  const { logout } = useAuth()
  const history = useHistory()

  const handleLogout = () => {
    logout()
    history.push("/login")
  }

  return (
    <IonMenu contentId="main-content">

      <IonContent>
        <div className="p-4 border-b">
          <img
            src="/sdcalogo.png"
            alt="St. Dominic College of Asia Logo"
            className="h-16 mx-auto"
          />
        </div>
        <IonList>
          <IonMenuToggle autoHide={false}>
            <IonItem button routerLink="/dashboard" routerDirection="root">
              <IonLabel>Dashboard</IonLabel>
            </IonItem>
          </IonMenuToggle>

          <IonMenuToggle autoHide={false}>
            <IonItem button routerLink="/personal-info" routerDirection="root">
              <IonLabel>Personal Information</IonLabel>
            </IonItem>
          </IonMenuToggle>

          <IonMenuToggle autoHide={false}>
            <IonItem button routerLink="/official-business" routerDirection="root">
              <IonLabel>Official Business Form</IonLabel>
            </IonItem>
          </IonMenuToggle>

          <IonMenuToggle autoHide={false}>
            <IonItem button routerLink="/change-schedule" routerDirection="root">
              <IonLabel>Change of Schedule</IonLabel>
            </IonItem>
          </IonMenuToggle>

          <IonMenuToggle autoHide={false}>
            <IonItem button onClick={handleLogout}>
              <IonLabel>Logout</IonLabel>
            </IonItem>
          </IonMenuToggle>
        </IonList>
      </IonContent>
    </IonMenu>
  )
}

