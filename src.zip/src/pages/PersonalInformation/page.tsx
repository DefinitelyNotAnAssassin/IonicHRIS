"use client"

import type React from "react"

import { useState, useEffect } from "react"
import {
  IonContent, IonPage, IonHeader, IonToolbar, IonTitle, IonButtons, IonMenuButton,
  IonCard, IonCardContent, IonCardHeader, IonCardTitle, IonCardSubtitle,
  IonInput, IonLabel, IonItem, IonList, IonButton, IonSegment, IonSegmentButton,
  IonDatetime, IonSelect, IonSelectOption, IonGrid, IonRow, IonCol, IonIcon, IonText
} from "@ionic/react"
import { useHistory } from "react-router-dom"
import { useAuth } from "../../hooks/use-auth"
import { add, close } from 'ionicons/icons'
import SideMenu from "@/components/side-menu"

export default function PersonalInfo() {
  const { user, isAuthenticated } = useAuth()
  const history = useHistory()
  const [activeTab, setActiveTab] = useState("personal")
  const [isLoading, setIsLoading] = useState(false)

  // Form data state
  const [personalData, setPersonalData] = useState({
    surname: "",
    firstName: "",
    middleName: "",
    suffix: "",
    nickname: "",
    presentAddress: "",
    provincialAddress: "",
    telephoneNo: "",
    mobileNo: "",
    emailAddress: "",
    dateOfBirth: "",
    placeOfBirth: "",
    age: "",
    gender: "",
    citizenship: "",
    civilStatus: "",
    height: "",
    weight: "",
    ssNo: "",
    tinNo: "",
    philHealthNo: "",
    pagIbigNo: "",
  })

  const [familyData, setFamilyData] = useState({
    spouseName: "",
    spouseOccupation: "",
    spouseCompany: "",
    fatherName: "",
    fatherOccupation: "",
    fatherCompany: "",
    motherName: "",
    motherOccupation: "",
    motherCompany: "",
    siblings: [{ name: "", occupation: "", company: "" }],
    dependents: [{ name: "", occupation: "", company: "" }],
  })

  const [educationData, setEducationData] = useState({
    bachelor: { level: "BACHELOR'S DEGREE", school: "", course: "", period: "" },
    postGrad: { level: "POST-GRADUATE", school: "", course: "", period: "" },
    masteral: { level: "MASTERAL", school: "", course: "", period: "" },
    doctoral: { level: "DOCTORATE", school: "", course: "", period: "" },
    vocational: { level: "VOCATIONAL/OTHERS", school: "", course: "", period: "" },
    honors: [{ nature: "", awardingBody: "", date: "" }],
    licensure: [{ exam: "", rating: "", dateTaken: "", licenseNo: "", issued: "", expiration: "" }],
  })

  useEffect(() => {
    if (!isAuthenticated) {
      history.push("/login")
    }
  }, [isAuthenticated, history])

  const handlePersonalChange = (e: any) => {
    const { name, value } = e.target
    setPersonalData((prev) => ({ ...prev, [name]: value }))
  }

  const handleCustomInputChange = (name: string, value: any) => {
    setPersonalData((prev) => ({ ...prev, [name]: value }))
  }

  const handleFamilyChange = (e: any) => {
    const { name, value } = e.target
    setFamilyData((prev) => ({ ...prev, [name]: value }))
  }

  const handleFamilyCustomChange = (name: string, value: any) => {
    setFamilyData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSiblingChange = (index: number, field: string, value: string) => {
    const updatedSiblings = [...familyData.siblings]
    updatedSiblings[index] = { ...updatedSiblings[index], [field]: value }
    setFamilyData((prev) => ({ ...prev, siblings: updatedSiblings }))
  }

  const handleDependentChange = (index: number, field: string, value: string) => {
    const updatedDependents = [...familyData.dependents]
    updatedDependents[index] = { ...updatedDependents[index], [field]: value }
    setFamilyData((prev) => ({ ...prev, dependents: updatedDependents }))
  }

  const addSibling = () => {
    setFamilyData((prev) => ({
      ...prev,
      siblings: [...prev.siblings, { name: "", occupation: "", company: "" }],
    }))
  }

  const addDependent = () => {
    setFamilyData((prev) => ({
      ...prev,
      dependents: [...prev.dependents, { name: "", occupation: "", company: "" }],
    }))
  }

  const removeSibling = (index: number) => {
    if (familyData.siblings.length > 1) {
      const updatedSiblings = [...familyData.siblings]
      updatedSiblings.splice(index, 1)
      setFamilyData((prev) => ({ ...prev, siblings: updatedSiblings }))
    }
  }

  const removeDependent = (index: number) => {
    if (familyData.dependents.length > 1) {
      const updatedDependents = [...familyData.dependents]
      updatedDependents.splice(index, 1)
      setFamilyData((prev) => ({ ...prev, dependents: updatedDependents }))
    }
  }

  const handleEducationChange = (level: string, field: string, value: string) => {
    setEducationData((prev) => ({
      ...prev,
      [level]: { ...prev[level as keyof typeof prev], [field]: value },
    }))
  }

  const handleHonorChange = (index: number, field: string, value: string) => {
    const updatedHonors = [...educationData.honors]
    updatedHonors[index] = { ...updatedHonors[index], [field]: value }
    setEducationData((prev) => ({ ...prev, honors: updatedHonors }))
  }

  const handleLicensureChange = (index: number, field: string, value: string) => {
    const updatedLicensure = [...educationData.licensure]
    updatedLicensure[index] = { ...updatedLicensure[index], [field]: value }
    setEducationData((prev) => ({ ...prev, licensure: updatedLicensure }))
  }

  const addHonor = () => {
    setEducationData((prev) => ({
      ...prev,
      honors: [...prev.honors, { nature: "", awardingBody: "", date: "" }],
    }))
  }

  const addLicensure = () => {
    setEducationData((prev) => ({
      ...prev,
      licensure: [
        ...prev.licensure,
        { exam: "", rating: "", dateTaken: "", licenseNo: "", issued: "", expiration: "" },
      ],
    }))
  }

  const removeHonor = (index: number) => {
    if (educationData.honors.length > 1) {
      const updatedHonors = [...educationData.honors]
      updatedHonors.splice(index, 1)
      setEducationData((prev) => ({ ...prev, honors: updatedHonors }))
    }
  }

  const removeLicensure = (index: number) => {
    if (educationData.licensure.length > 1) {
      const updatedLicensure = [...educationData.licensure]
      updatedLicensure.splice(index, 1)
      setEducationData((prev) => ({ ...prev, licensure: updatedLicensure }))
    }
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    // In a real app, this would be an API call to save the data
    setTimeout(() => {
      setIsLoading(false)
      presentToast({
        message: "Your personal information has been updated successfully",
        duration: 2000,
        color: "success"
      });
    }, 1500)
  }

  const presentToast = (options: {message: string, duration: number, color: string}) => {
    // In a real implementation, you would use IonToast controller
    // This is a simple implementation for demo purposes
    console.log(options.message);
  }

  return (
    <>
      <SideMenu />
      <IonPage id="main-content" className="p-8">
        <IonHeader>
          <IonToolbar>
            <IonButtons slot="start">
              <IonMenuButton></IonMenuButton>
            </IonButtons>
            <IonTitle>Personal Information</IonTitle>
          </IonToolbar>
        </IonHeader>
        <IonContent className="">
          <IonCard className="mt-8 py-8 px-4 rounded-lg ">
            <IonCardHeader>
              <IonCardTitle>Employment Application Form</IonCardTitle>
              <IonCardSubtitle>Please fill out all the required information</IonCardSubtitle>
            </IonCardHeader>
            <IonCardContent>
              <IonSegment value={activeTab} onIonChange={e => setActiveTab(e.detail.value as string)}>
                <IonSegmentButton value="personal">
                  <IonLabel>Personal Data</IonLabel>
                </IonSegmentButton>
                <IonSegmentButton value="family">
                  <IonLabel>Family Information</IonLabel>
                </IonSegmentButton>
                <IonSegmentButton value="education">
                  <IonLabel>Academic Data</IonLabel>
                </IonSegmentButton>
              </IonSegment>

              {/* Personal Tab Content */}
              {activeTab === "personal" && (
                <div className="ion-padding-top">
                  <IonGrid>
                    <IonRow>
                      <IonCol size="12" sizeMd="6">
                        <IonItem>
                          <IonLabel position="floating">Surname</IonLabel>
                          <IonInput
                            name="surname"
                            value={personalData.surname}
                            onIonChange={(e) => handleCustomInputChange("surname", e.detail.value)}
                          />
                        </IonItem>
                      </IonCol>
                      <IonCol size="12" sizeMd="6">
                        <IonItem>
                          <IonLabel position="floating">First Name</IonLabel>
                          <IonInput
                            name="firstName"
                            value={personalData.firstName}
                            onIonChange={(e) => handleCustomInputChange("firstName", e.detail.value)}
                          />
                        </IonItem>
                      </IonCol>
                    </IonRow>

                    <IonRow>
                      <IonCol size="12" sizeMd="6">
                        <IonItem>
                          <IonLabel position="floating">Middle Name</IonLabel>
                          <IonInput
                            name="middleName"
                            value={personalData.middleName}
                            onIonChange={(e) => handleCustomInputChange("middleName", e.detail.value)}
                          />
                        </IonItem>
                      </IonCol>
                      <IonCol size="6" sizeMd="3">
                        <IonItem>
                          <IonLabel position="floating">Suffix</IonLabel>
                          <IonInput
                            name="suffix"
                            value={personalData.suffix}
                            onIonChange={(e) => handleCustomInputChange("suffix", e.detail.value)}
                          />
                        </IonItem>
                      </IonCol>
                      <IonCol size="6" sizeMd="3">
                        <IonItem>
                          <IonLabel position="floating">Nickname</IonLabel>
                          <IonInput
                            name="nickname"
                            value={personalData.nickname}
                            onIonChange={(e) => handleCustomInputChange("nickname", e.detail.value)}
                          />
                        </IonItem>
                      </IonCol>
                    </IonRow>

                    <IonRow>
                      <IonCol size="12">
                        <IonItem>
                          <IonLabel position="floating">Present Address</IonLabel>
                          <IonInput
                            name="presentAddress"
                            value={personalData.presentAddress}
                            onIonChange={(e) => handleCustomInputChange("presentAddress", e.detail.value)}
                          />
                        </IonItem>
                      </IonCol>
                    </IonRow>

                    <IonRow>
                      <IonCol size="12">
                        <IonItem>
                          <IonLabel position="floating">Provincial Address</IonLabel>
                          <IonInput
                            name="provincialAddress"
                            value={personalData.provincialAddress}
                            onIonChange={(e) => handleCustomInputChange("provincialAddress", e.detail.value)}
                          />
                        </IonItem>
                      </IonCol>
                    </IonRow>

                    <IonRow>
                      <IonCol size="12" sizeMd="6">
                        <IonItem>
                          <IonLabel position="floating">Telephone No.</IonLabel>
                          <IonInput
                            name="telephoneNo"
                            value={personalData.telephoneNo}
                            onIonChange={(e) => handleCustomInputChange("telephoneNo", e.detail.value)}
                          />
                        </IonItem>
                      </IonCol>
                      <IonCol size="12" sizeMd="6">
                        <IonItem>
                          <IonLabel position="floating">Mobile No.</IonLabel>
                          <IonInput
                            name="mobileNo"
                            value={personalData.mobileNo}
                            onIonChange={(e) => handleCustomInputChange("mobileNo", e.detail.value)}
                          />
                        </IonItem>
                      </IonCol>
                    </IonRow>

                    <IonRow>
                      <IonCol size="12">
                        <IonItem>
                          <IonLabel position="floating">Email Address</IonLabel>
                          <IonInput
                            name="emailAddress"
                            type="email"
                            value={personalData.emailAddress}
                            onIonChange={(e) => handleCustomInputChange("emailAddress", e.detail.value)}
                          />
                        </IonItem>
                      </IonCol>
                    </IonRow>

                    <IonRow>
                      <IonCol size="12" sizeMd="4">
                        <IonItem>
                          <IonLabel position="floating">Date of Birth</IonLabel>
                          <IonInput
                            name="dateOfBirth"
                            type="date"
                            value={personalData.dateOfBirth}
                            onIonChange={(e) => handleCustomInputChange("dateOfBirth", e.detail.value)}
                          />
                        </IonItem>
                      </IonCol>
                      <IonCol size="12" sizeMd="4">
                        <IonItem>
                          <IonLabel position="floating">Place of Birth</IonLabel>
                          <IonInput
                            name="placeOfBirth"
                            value={personalData.placeOfBirth}
                            onIonChange={(e) => handleCustomInputChange("placeOfBirth", e.detail.value)}
                          />
                        </IonItem>
                      </IonCol>
                      <IonCol size="12" sizeMd="4">
                        <IonItem>
                          <IonLabel position="floating">Age</IonLabel>
                          <IonInput
                            name="age"
                            type="number"
                            value={personalData.age}
                            onIonChange={(e) => handleCustomInputChange("age", e.detail.value)}
                          />
                        </IonItem>
                      </IonCol>
                    </IonRow>

                    <IonRow>
                      <IonCol size="12" sizeMd="4">
                        <IonItem>
                          <IonLabel position="floating">Gender</IonLabel>
                          <IonSelect
                            name="gender"
                            value={personalData.gender}
                            onIonChange={(e) => handleCustomInputChange("gender", e.detail.value)}
                          >
                            <IonSelectOption value="">Select Gender</IonSelectOption>
                            <IonSelectOption value="Male">Male</IonSelectOption>
                            <IonSelectOption value="Female">Female</IonSelectOption>
                          </IonSelect>
                        </IonItem>
                      </IonCol>
                      <IonCol size="12" sizeMd="4">
                        <IonItem>
                          <IonLabel position="floating">Citizenship</IonLabel>
                          <IonInput
                            name="citizenship"
                            value={personalData.citizenship}
                            onIonChange={(e) => handleCustomInputChange("citizenship", e.detail.value)}
                          />
                        </IonItem>
                      </IonCol>
                      <IonCol size="12" sizeMd="4">
                        <IonItem>
                          <IonLabel position="floating">Civil Status</IonLabel>
                          <IonSelect
                            name="civilStatus"
                            value={personalData.civilStatus}
                            onIonChange={(e) => handleCustomInputChange("civilStatus", e.detail.value)}
                          >
                            <IonSelectOption value="">Select Status</IonSelectOption>
                            <IonSelectOption value="Single">Single</IonSelectOption>
                            <IonSelectOption value="Married">Married</IonSelectOption>
                            <IonSelectOption value="Widowed">Widowed</IonSelectOption>
                            <IonSelectOption value="Separated">Separated</IonSelectOption>
                          </IonSelect>
                        </IonItem>
                      </IonCol>
                    </IonRow>

                    <IonRow>
                      <IonCol size="12" sizeMd="6">
                        <IonItem>
                          <IonLabel position="floating">Height (cm)</IonLabel>
                          <IonInput
                            name="height"
                            type="number"
                            value={personalData.height}
                            onIonChange={(e) => handleCustomInputChange("height", e.detail.value)}
                          />
                        </IonItem>
                      </IonCol>
                      <IonCol size="12" sizeMd="6">
                        <IonItem>
                          <IonLabel position="floating">Weight (kg)</IonLabel>
                          <IonInput
                            name="weight"
                            type="number"
                            value={personalData.weight}
                            onIonChange={(e) => handleCustomInputChange("weight", e.detail.value)}
                          />
                        </IonItem>
                      </IonCol>
                    </IonRow>

                    <IonRow>
                      <IonCol size="12" sizeMd="6">
                        <IonItem>
                          <IonLabel position="floating">SS No.</IonLabel>
                          <IonInput 
                            name="ssNo" 
                            value={personalData.ssNo}
                            onIonChange={(e) => handleCustomInputChange("ssNo", e.detail.value)} 
                          />
                        </IonItem>
                      </IonCol>
                      <IonCol size="12" sizeMd="6">
                        <IonItem>
                          <IonLabel position="floating">Tax Identification No. (TIN)</IonLabel>
                          <IonInput 
                            name="tinNo" 
                            value={personalData.tinNo}
                            onIonChange={(e) => handleCustomInputChange("tinNo", e.detail.value)} 
                          />
                        </IonItem>
                      </IonCol>
                    </IonRow>

                    <IonRow>
                      <IonCol size="12" sizeMd="6">
                        <IonItem>
                          <IonLabel position="floating">PhilHealth Identification No. (PIN)</IonLabel>
                          <IonInput
                            name="philHealthNo"
                            value={personalData.philHealthNo}
                            onIonChange={(e) => handleCustomInputChange("philHealthNo", e.detail.value)}
                          />
                        </IonItem>
                      </IonCol>
                      <IonCol size="12" sizeMd="6">
                        <IonItem>
                          <IonLabel position="floating">Pag-IBIG MID No.</IonLabel>
                          <IonInput
                            name="pagIbigNo"
                            value={personalData.pagIbigNo}
                            onIonChange={(e) => handleCustomInputChange("pagIbigNo", e.detail.value)}
                          />
                        </IonItem>
                      </IonCol>
                    </IonRow>
                  </IonGrid>
                </div>
              )}

              {/* Family Tab Content */}
              {activeTab === "family" && (
                <div className="ion-padding-top">
                  <IonGrid>
                    <IonRow>
                      <IonCol size="12" sizeMd="4">
                        <IonItem>
                          <IonLabel position="floating">Name of Spouse</IonLabel>
                          <IonInput
                            name="spouseName"
                            value={familyData.spouseName}
                            onIonChange={(e) => handleFamilyCustomChange("spouseName", e.detail.value)}
                          />
                        </IonItem>
                      </IonCol>
                      <IonCol size="12" sizeMd="4">
                        <IonItem>
                          <IonLabel position="floating">Occupation</IonLabel>
                          <IonInput
                            name="spouseOccupation"
                            value={familyData.spouseOccupation}
                            onIonChange={(e) => handleFamilyCustomChange("spouseOccupation", e.detail.value)}
                          />
                        </IonItem>
                      </IonCol>
                      <IonCol size="12" sizeMd="4">
                        <IonItem>
                          <IonLabel position="floating">Company</IonLabel>
                          <IonInput
                            name="spouseCompany"
                            value={familyData.spouseCompany}
                            onIonChange={(e) => handleFamilyCustomChange("spouseCompany", e.detail.value)}
                          />
                        </IonItem>
                      </IonCol>
                    </IonRow>

                    <IonRow>
                      <IonCol size="12" sizeMd="4">
                        <IonItem>
                          <IonLabel position="floating">Father's Name</IonLabel>
                          <IonInput
                            name="fatherName"
                            value={familyData.fatherName}
                            onIonChange={(e) => handleFamilyCustomChange("fatherName", e.detail.value)}
                          />
                        </IonItem>
                      </IonCol>
                      <IonCol size="12" sizeMd="4">
                        <IonItem>
                          <IonLabel position="floating">Occupation</IonLabel>
                          <IonInput
                            name="fatherOccupation"
                            value={familyData.fatherOccupation}
                            onIonChange={(e) => handleFamilyCustomChange("fatherOccupation", e.detail.value)}
                          />
                        </IonItem>
                      </IonCol>
                      <IonCol size="12" sizeMd="4">
                        <IonItem>
                          <IonLabel position="floating">Company</IonLabel>
                          <IonInput
                            name="fatherCompany"
                            value={familyData.fatherCompany}
                            onIonChange={(e) => handleFamilyCustomChange("fatherCompany", e.detail.value)}
                          />
                        </IonItem>
                      </IonCol>
                    </IonRow>

                    <IonRow>
                      <IonCol size="12" sizeMd="4">
                        <IonItem>
                          <IonLabel position="floating">Mother's Name</IonLabel>
                          <IonInput
                            name="motherName"
                            value={familyData.motherName}
                            onIonChange={(e) => handleFamilyCustomChange("motherName", e.detail.value)}
                          />
                        </IonItem>
                      </IonCol>
                      <IonCol size="12" sizeMd="4">
                        <IonItem>
                          <IonLabel position="floating">Occupation</IonLabel>
                          <IonInput
                            name="motherOccupation"
                            value={familyData.motherOccupation}
                            onIonChange={(e) => handleFamilyCustomChange("motherOccupation", e.detail.value)}
                          />
                        </IonItem>
                      </IonCol>
                      <IonCol size="12" sizeMd="4">
                        <IonItem>
                          <IonLabel position="floating">Company</IonLabel>
                          <IonInput
                            name="motherCompany"
                            value={familyData.motherCompany}
                            onIonChange={(e) => handleFamilyCustomChange("motherCompany", e.detail.value)}
                          />
                        </IonItem>
                      </IonCol>
                    </IonRow>

                    <IonRow className="ion-padding-top">
                      <IonCol size="12">
                        <IonItem lines="none">
                          <IonLabel>List of Siblings</IonLabel>
                          <IonButton slot="end" size="small" onClick={addSibling}>
                            <IonIcon slot="icon-only" icon={add} />
                          </IonButton>
                        </IonItem>
                      </IonCol>
                    </IonRow>

                    {familyData.siblings.map((sibling, index) => (
                      <IonCard key={index} className="ion-margin-vertical">
                        <IonCardContent>
                          <IonRow>
                            <IonCol size="12" sizeMd="4">
                              <IonItem>
                                <IonLabel position="floating">Name</IonLabel>
                                <IonInput
                                  value={sibling.name}
                                  onIonChange={(e) => handleSiblingChange(index, "name", e.detail.value || "")}
                                />
                              </IonItem>
                            </IonCol>
                            <IonCol size="12" sizeMd="4">
                              <IonItem>
                                <IonLabel position="floating">Occupation</IonLabel>
                                <IonInput
                                  value={sibling.occupation}
                                  onIonChange={(e) => handleSiblingChange(index, "occupation", e.detail.value || "")}
                                />
                              </IonItem>
                            </IonCol>
                            <IonCol size="12" sizeMd="3">
                              <IonItem>
                                <IonLabel position="floating">Company</IonLabel>
                                <IonInput
                                  value={sibling.company}
                                  onIonChange={(e) => handleSiblingChange(index, "company", e.detail.value || "")}
                                />
                              </IonItem>
                            </IonCol>
                            {familyData.siblings.length > 1 && (
                              <IonCol size="12" sizeMd="1" className="ion-align-self-end">
                                <IonButton 
                                  color="danger" 
                                  fill="clear"
                                  onClick={() => removeSibling(index)}
                                >
                                  <IonIcon icon={close} />
                                </IonButton>
                              </IonCol>
                            )}
                          </IonRow>
                        </IonCardContent>
                      </IonCard>
                    ))}

                    <IonRow className="ion-padding-top">
                      <IonCol size="12">
                        <IonItem lines="none">
                          <IonLabel>List of Dependents</IonLabel>
                          <IonButton slot="end" size="small" onClick={addDependent}>
                            <IonIcon slot="icon-only" icon={add} />
                          </IonButton>
                        </IonItem>
                      </IonCol>
                    </IonRow>

                    {familyData.dependents.map((dependent, index) => (
                      <IonCard key={index} className="ion-margin-vertical">
                        <IonCardContent>
                          <IonRow>
                            <IonCol size="12" sizeMd="4">
                              <IonItem>
                                <IonLabel position="floating">Name</IonLabel>
                                <IonInput
                                  value={dependent.name}
                                  onIonChange={(e) => handleDependentChange(index, "name", e.detail.value || "")}
                                />
                              </IonItem>
                            </IonCol>
                            <IonCol size="12" sizeMd="4">
                              <IonItem>
                                <IonLabel position="floating">Occupation</IonLabel>
                                <IonInput
                                  value={dependent.occupation}
                                  onIonChange={(e) => handleDependentChange(index, "occupation", e.detail.value || "")}
                                />
                              </IonItem>
                            </IonCol>
                            <IonCol size="12" sizeMd="3">
                              <IonItem>
                                <IonLabel position="floating">Company</IonLabel>
                                <IonInput
                                  value={dependent.company}
                                  onIonChange={(e) => handleDependentChange(index, "company", e.detail.value || "")}
                                />
                              </IonItem>
                            </IonCol>
                            {familyData.dependents.length > 1 && (
                              <IonCol size="12" sizeMd="1" className="ion-align-self-end">
                                <IonButton 
                                  color="danger" 
                                  fill="clear"
                                  onClick={() => removeDependent(index)}
                                >
                                  <IonIcon icon={close} />
                                </IonButton>
                              </IonCol>
                            )}
                          </IonRow>
                        </IonCardContent>
                      </IonCard>
                    ))}
                  </IonGrid>
                </div>
              )}

              {/* Education Tab Content */}
              {activeTab === "education" && (
                <div className="ion-padding-top">
                  <IonGrid>
                    <IonRow>
                      <IonCol size="12">
                        <IonText>
                          <h3>Academic Data</h3>
                        </IonText>
                      </IonCol>
                    </IonRow>

                    {Object.entries(educationData)
                      .slice(0, 5)
                      .map(([key, value]) => {
                        if (typeof value === "object" && "level" in value) {
                          const education = value as { level: string; school: string; course: string; period: string }
                          return (
                            <IonCard key={key} className="ion-margin-vertical">
                              <IonCardContent>
                                <IonRow>
                                  <IonCol size="12">
                                    <IonItem lines="none">
                                      <IonLabel color="primary">{education.level}</IonLabel>
                                    </IonItem>
                                  </IonCol>
                                </IonRow>
                                <IonRow>
                                  <IonCol size="12" sizeMd="4">
                                    <IonItem>
                                      <IonLabel position="floating">School/Location</IonLabel>
                                      <IonInput
                                        value={education.school}
                                        onIonChange={(e) => handleEducationChange(key, "school", e.detail.value || "")}
                                      />
                                    </IonItem>
                                  </IonCol>
                                  <IonCol size="12" sizeMd="4">
                                    <IonItem>
                                      <IonLabel position="floating">Course/Program</IonLabel>
                                      <IonInput
                                        value={education.course}
                                        onIonChange={(e) => handleEducationChange(key, "course", e.detail.value || "")}
                                      />
                                    </IonItem>
                                  </IonCol>
                                  <IonCol size="12" sizeMd="4">
                                    <IonItem>
                                      <IonLabel position="floating">Period Covered</IonLabel>
                                      <IonInput
                                        value={education.period}
                                        placeholder="e.g., 2015-2019"
                                        onIonChange={(e) => handleEducationChange(key, "period", e.detail.value || "")}
                                      />
                                    </IonItem>
                                  </IonCol>
                                </IonRow>
                              </IonCardContent>
                            </IonCard>
                          )
                        }
                        return null
                      })}

                    <IonRow className="ion-padding-top">
                      <IonCol size="12">
                        <IonItem lines="none">
                          <IonLabel>Honors and Awards</IonLabel>
                          <IonButton slot="end" size="small" onClick={addHonor}>
                            <IonIcon slot="icon-only" icon={add} />
                          </IonButton>
                        </IonItem>
                      </IonCol>
                    </IonRow>

                    {educationData.honors.map((honor, index) => (
                      <IonCard key={index} className="ion-margin-vertical">
                        <IonCardContent>
                          <IonRow>
                            <IonCol size="12" sizeMd="4">
                              <IonItem>
                                <IonLabel position="floating">Nature of Award</IonLabel>
                                <IonInput
                                  value={honor.nature}
                                  onIonChange={(e) => handleHonorChange(index, "nature", e.detail.value || "")}
                                />
                              </IonItem>
                            </IonCol>
                            <IonCol size="12" sizeMd="4">
                              <IonItem>
                                <IonLabel position="floating">Award Giving Body</IonLabel>
                                <IonInput
                                  value={honor.awardingBody}
                                  onIonChange={(e) => handleHonorChange(index, "awardingBody", e.detail.value || "")}
                                />
                              </IonItem>
                            </IonCol>
                            <IonCol size="12" sizeMd="3">
                              <IonItem>
                                <IonLabel position="floating">Date</IonLabel>
                                <IonInput
                                  type="date"
                                  value={honor.date}
                                  onIonChange={(e) => handleHonorChange(index, "date", e.detail.value || "")}
                                />
                              </IonItem>
                            </IonCol>
                            {educationData.honors.length > 1 && (
                              <IonCol size="12" sizeMd="1" className="ion-align-self-end">
                                <IonButton 
                                  color="danger" 
                                  fill="clear"
                                  onClick={() => removeHonor(index)}
                                >
                                  <IonIcon icon={close} />
                                </IonButton>
                              </IonCol>
                            )}
                          </IonRow>
                        </IonCardContent>
                      </IonCard>
                    ))}

                    <IonRow className="ion-padding-top">
                      <IonCol size="12">
                        <IonItem lines="none">
                          <IonLabel>Licensure Examination</IonLabel>
                          <IonButton slot="end" size="small" onClick={addLicensure}>
                            <IonIcon slot="icon-only" icon={add} />
                          </IonButton>
                        </IonItem>
                      </IonCol>
                    </IonRow>

                    {educationData.licensure.map((license, index) => (
                      <IonCard key={index} className="ion-margin-vertical">
                        <IonCardContent>
                          <IonRow>
                            <IonCol size="12" sizeMd="4">
                              <IonItem>
                                <IonLabel position="floating">Board Examination</IonLabel>
                                <IonInput
                                  value={license.exam}
                                  onIonChange={(e) => handleLicensureChange(index, "exam", e.detail.value || "")}
                                />
                              </IonItem>
                            </IonCol>
                            <IonCol size="12" sizeMd="4">
                              <IonItem>
                                <IonLabel position="floating">Rating</IonLabel>
                                <IonInput
                                  value={license.rating}
                                  onIonChange={(e) => handleLicensureChange(index, "rating", e.detail.value || "")}
                                />
                              </IonItem>
                            </IonCol>
                            <IonCol size="12" sizeMd="4">
                              <IonItem>
                                <IonLabel position="floating">Date Taken</IonLabel>
                                <IonInput
                                  type="date"
                                  value={license.dateTaken}
                                  onIonChange={(e) => handleLicensureChange(index, "dateTaken", e.detail.value || "")}
                                />
                              </IonItem>
                            </IonCol>
                          </IonRow>
                          <IonRow>
                            <IonCol size="12" sizeMd="4">
                              <IonItem>
                                <IonLabel position="floating">License No.</IonLabel>
                                <IonInput
                                  value={license.licenseNo}
                                  onIonChange={(e) => handleLicensureChange(index, "licenseNo", e.detail.value || "")}
                                />
                              </IonItem>
                            </IonCol>
                            <IonCol size="12" sizeMd="4">
                              <IonItem>
                                <IonLabel position="floating">Issued</IonLabel>
                                <IonInput
                                  type="date"
                                  value={license.issued}
                                  onIonChange={(e) => handleLicensureChange(index, "issued", e.detail.value || "")}
                                />
                              </IonItem>
                            </IonCol>
                            <IonCol size="12" sizeMd="3">
                              <IonItem>
                                <IonLabel position="floating">Expiration</IonLabel>
                                <IonInput
                                  type="date"
                                  value={license.expiration}
                                  onIonChange={(e) => handleLicensureChange(index, "expiration", e.detail.value || "")}
                                />
                              </IonItem>
                            </IonCol>
                            {educationData.licensure.length > 1 && (
                              <IonCol size="12" sizeMd="1" className="ion-align-self-end">
                                <IonButton 
                                  color="danger" 
                                  fill="clear"
                                  onClick={() => removeLicensure(index)}
                                >
                                  <IonIcon icon={close} />
                                </IonButton>
                              </IonCol>
                            )}
                          </IonRow>
                        </IonCardContent>
                      </IonCard>
                    ))}
                  </IonGrid>
                </div>
              )}
            </IonCardContent>

            <div className="ion-padding">
              <IonRow>
                <IonCol className="ion-text-start">
                  <IonButton fill="outline" onClick={() => history.push("/dashboard")}>
                    Cancel
                  </IonButton>
                </IonCol>
                <IonCol className="ion-text-end">
                  <IonButton onClick={handleSubmit} disabled={isLoading}>
                    {isLoading ? "Saving..." : "Save Information"}
                  </IonButton>
                </IonCol>
              </IonRow>
            </div>
          </IonCard>
        </IonContent>
      </IonPage>
    </>
  )
}