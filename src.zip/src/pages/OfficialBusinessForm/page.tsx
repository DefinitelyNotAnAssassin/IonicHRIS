"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { IonContent, IonPage, IonHeader, IonToolbar, IonTitle, IonButtons, IonMenuButton } from "@ionic/react"
import { useHistory } from "react-router-dom"
import { useAuth } from "@/hooks/use-auth"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { useToast } from "@/components/ui/use-toast"
import SideMenu from "@/components/side-menu"

export default function OfficialBusiness() {
  const { user, isAuthenticated } = useAuth()
  const history = useHistory()
  const { toast } = useToast()
  const [isLoading, setIsLoading] = useState(false)

  const [formData, setFormData] = useState({
    department: "",
    employeeName: "",
    purpose: "",
    timeOfDeparture: "",
    timeOfArrival: "",
    date: new Date().toISOString().split("T")[0],
    receivedBy: "",
    dateReceived: "",
    approvedBy: "",
  })

  useEffect(() => {
    if (!isAuthenticated) {
      history.push("/login")
    }

    // Pre-fill employee name if available
    if (user?.name) {
      setFormData((prev) => ({ ...prev, employeeName: user.name }))
    }
  }, [isAuthenticated, history, user])

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    // In a real app, this would be an API call to save the data
    setTimeout(() => {
      setIsLoading(false)
      toast({
        title: "Form submitted",
        description: "Your official business form has been submitted successfully",
      })
      history.push("/dashboard")
    }, 1500)
  }

  return (
    <>
      <SideMenu />
      <IonPage id="main-content">
        <IonHeader>
          <IonToolbar>
            <IonButtons slot="start">
              <IonMenuButton></IonMenuButton>
            </IonButtons>
            <IonTitle>Official Business Form</IonTitle>
          </IonToolbar>
        </IonHeader>
        <IonContent className="ion-padding">
          <div className="container mx-auto p-4">
            <Card className="mb-6">
              <CardHeader>
                <CardTitle>Official Business Form</CardTitle>
                <CardDescription>Fill out this form to request official business</CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="date">Date of Official Business</Label>
                      <Input id="date" name="date" type="date" value={formData.date} onChange={handleChange} required />
                    </div>
                    <div>
                      <Label htmlFor="department">Department</Label>
                      <Input
                        id="department"
                        name="department"
                        value={formData.department}
                        onChange={handleChange}
                        required
                      />
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="employeeName">Employee's Name</Label>
                    <Input
                      id="employeeName"
                      name="employeeName"
                      value={formData.employeeName}
                      onChange={handleChange}
                      required
                    />
                  </div>

                  <div>
                    <Label htmlFor="purpose">Purpose</Label>
                    <Textarea
                      id="purpose"
                      name="purpose"
                      value={formData.purpose}
                      onChange={handleChange}
                      required
                      className="min-h-[100px]"
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="timeOfDeparture">Time of Departure</Label>
                      <Input
                        id="timeOfDeparture"
                        name="timeOfDeparture"
                        type="time"
                        value={formData.timeOfDeparture}
                        onChange={handleChange}
                        required
                      />
                    </div>
                    <div>
                      <Label htmlFor="timeOfArrival">Time of Arrival</Label>
                      <Input
                        id="timeOfArrival"
                        name="timeOfArrival"
                        type="time"
                        value={formData.timeOfArrival}
                        onChange={handleChange}
                        required
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                      <Label htmlFor="approvedBy">Approved by (Immediate Superior)</Label>
                      <Input id="approvedBy" name="approvedBy" value={formData.approvedBy} onChange={handleChange} />
                    </div>
                    <div>
                      <Label htmlFor="receivedBy">Received by (HRO)</Label>
                      <Input
                        id="receivedBy"
                        name="receivedBy"
                        value={formData.receivedBy}
                        onChange={handleChange}
                        disabled
                      />
                    </div>
                    <div>
                      <Label htmlFor="dateReceived">Date Received</Label>
                      <Input
                        id="dateReceived"
                        name="dateReceived"
                        type="date"
                        value={formData.dateReceived}
                        onChange={handleChange}
                        disabled
                      />
                    </div>
                  </div>

                  <div className="border-t pt-4 mt-4">
                    <p className="text-sm text-muted-foreground mb-4">
                      Note: Official Business Form of all Teachers and Faculty Members must be signed by the Academic
                      Coordinator or Program Chair.
                    </p>
                  </div>
                </form>
              </CardContent>
              <CardFooter className="flex justify-between">
                <Button variant="outline" onClick={() => history.push("/dashboard")}>
                  Cancel
                </Button>
                <Button onClick={handleSubmit} disabled={isLoading}>
                  {isLoading ? "Submitting..." : "Submit Form"}
                </Button>
              </CardFooter>
            </Card>
          </div>
        </IonContent>
      </IonPage>
    </>
  )
}

