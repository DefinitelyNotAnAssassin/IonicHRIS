"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { 
  IonContent, 
  IonPage, 
  IonHeader, 
  IonToolbar, 
  IonTitle, 
  IonButtons, 
  IonMenuButton,
  IonButton,
  IonInput,
  IonLabel,
  IonTextarea,
  IonCard,
  IonCardHeader,
  IonCardTitle,
  IonCardSubtitle,
  IonCardContent,
  IonItem,
  IonList,
  IonGrid,
  IonRow,
  IonCol,
  IonDatetime,
  IonRadioGroup,
  IonRadio,
  IonText,
  IonNote
} from "@ionic/react"
import { useHistory } from "react-router-dom"
import { useAuth } from "@/hooks/use-auth"
import SideMenu from "@/components/side-menu"

export default function ChangeSchedule() {
  const { user, isAuthenticated } = useAuth()
  const history = useHistory()
  const [isLoading, setIsLoading] = useState(false)

  const [formData, setFormData] = useState({
    employeeName: "",
    position: "",
    department: "",
    employmentStatus: {
      category: "administrative", // administrative or academics
      type: "regular", // regular, probationary, contractual
      time: "full-time", // full-time, part-time
    },
    dateOfAbsence: new Date().toISOString().split("T")[0],
    officialTime: "",
    requestedDate: new Date().toISOString().split("T")[0],
    requestedTime: "",
    reason: "",
    approvedBy: "",
    receivedBy: "",
    dateReceived: "",
  })

  useEffect(() => {
    if (!isAuthenticated) {
      history.push("/login")
    }

    // Pre-fill employee name if available
    if (user?.name) {
      setFormData((prev) => ({ ...prev, employeeName: user.name }))
    }
  }, [isAuthenticated, history, user])

  const handleChange = (e: any) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleEmploymentStatusChange = (field: string, value: string) => {
    setFormData((prev) => ({
      ...prev,
      employmentStatus: {
        ...prev.employmentStatus,
        [field]: value,
      },
    }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    // In a real app, this would be an API call to save the data
    setTimeout(() => {
      setIsLoading(false)
      presentToast("Your change of schedule request has been submitted successfully")
      history.push("/dashboard")
    }, 1500)
  }

  const presentToast = (message: string) => {
    const toast = document.createElement('ion-toast');
    toast.message = message;
    toast.duration = 2000;
    toast.position = 'bottom';
    document.body.appendChild(toast);
    return toast.present();
  }

  return (
    <>
      <SideMenu />
      <IonPage id="main-content">
        <IonHeader>
          <IonToolbar>
            <IonButtons slot="start">
              <IonMenuButton></IonMenuButton>
            </IonButtons>
            <IonTitle>Change of Schedule</IonTitle>
          </IonToolbar>
        </IonHeader>
        <IonContent className="ion-padding">
          <IonCard>
            <IonCardHeader>
              <IonCardTitle>Application for Change of Schedule</IonCardTitle>
              <IonCardSubtitle>Fill out this form to request a change in your work schedule</IonCardSubtitle>
            </IonCardHeader>
            <IonCardContent>
              <form onSubmit={handleSubmit}>
                <IonGrid>
                  <IonRow>
                    <IonCol size="12" sizeMd="6">
                      <IonItem>
                        <IonLabel position="stacked">Employee's Name</IonLabel>
                        <IonInput 
                          name="employeeName"
                          value={formData.employeeName}
                          onIonChange={handleChange}
                          required
                        ></IonInput>
                      </IonItem>
                    </IonCol>
                    <IonCol size="12" sizeMd="6">
                      <IonItem>
                        <IonLabel position="stacked">Position</IonLabel>
                        <IonInput 
                          name="position"
                          value={formData.position}
                          onIonChange={handleChange}
                          required
                        ></IonInput>
                      </IonItem>
                    </IonCol>
                  </IonRow>

                  <IonRow>
                    <IonCol>
                      <IonItem>
                        <IonLabel position="stacked">Department</IonLabel>
                        <IonInput 
                          name="department"
                          value={formData.department}
                          onIonChange={handleChange}
                          required
                        ></IonInput>
                      </IonItem>
                    </IonCol>
                  </IonRow>

                  <IonRow className="ion-margin-top">
                    <IonCol>
                      <IonText>
                        <h4>Employment Status</h4>
                      </IonText>
                    </IonCol>
                  </IonRow>

                  <IonRow>
                    <IonCol size="12" sizeMd="4">
                      <IonList>
                        <IonItem>
                          <IonLabel>Category</IonLabel>
                        </IonItem>
                        <IonRadioGroup 
                          value={formData.employmentStatus.category}
                          onIonChange={e => handleEmploymentStatusChange("category", e.detail.value)}
                        >
                          <IonItem>
                            <IonLabel>Administrative</IonLabel>
                            <IonRadio slot="start" value="administrative" />
                          </IonItem>
                          <IonItem>
                            <IonLabel>Academics</IonLabel>
                            <IonRadio slot="start" value="academics" />
                          </IonItem>
                        </IonRadioGroup>
                      </IonList>
                    </IonCol>
                    
                    <IonCol size="12" sizeMd="4">
                      <IonList>
                        <IonItem>
                          <IonLabel>Type</IonLabel>
                        </IonItem>
                        <IonRadioGroup 
                          value={formData.employmentStatus.type}
                          onIonChange={e => handleEmploymentStatusChange("type", e.detail.value)}
                        >
                          <IonItem>
                            <IonLabel>Regular</IonLabel>
                            <IonRadio slot="start" value="regular" />
                          </IonItem>
                          <IonItem>
                            <IonLabel>Probationary</IonLabel>
                            <IonRadio slot="start" value="probationary" />
                          </IonItem>
                          <IonItem>
                            <IonLabel>Contractual</IonLabel>
                            <IonRadio slot="start" value="contractual" />
                          </IonItem>
                        </IonRadioGroup>
                      </IonList>
                    </IonCol>
                    
                    <IonCol size="12" sizeMd="4">
                      <IonList>
                        <IonItem>
                          <IonLabel>Time</IonLabel>
                        </IonItem>
                        <IonRadioGroup 
                          value={formData.employmentStatus.time}
                          onIonChange={e => handleEmploymentStatusChange("time", e.detail.value)}
                        >
                          <IonItem>
                            <IonLabel>Full-time</IonLabel>
                            <IonRadio slot="start" value="full-time" />
                          </IonItem>
                          <IonItem>
                            <IonLabel>Part-time</IonLabel>
                            <IonRadio slot="start" value="part-time" />
                          </IonItem>
                        </IonRadioGroup>
                      </IonList>
                    </IonCol>
                  </IonRow>

                  <IonRow>
                    <IonCol size="12" sizeMd="6">
                      <IonItem>
                        <IonLabel position="stacked">Date of Absence</IonLabel>
                        <IonInput 
                          name="dateOfAbsence"
                          type="date"
                          value={formData.dateOfAbsence}
                          onIonChange={handleChange}
                          required
                        ></IonInput>
                      </IonItem>
                    </IonCol>
                    <IonCol size="12" sizeMd="6">
                      <IonItem>
                        <IonLabel position="stacked">Official Time</IonLabel>
                        <IonInput 
                          name="officialTime"
                          placeholder="e.g., 8:00 - 5:00"
                          value={formData.officialTime}
                          onIonChange={handleChange}
                          required
                        ></IonInput>
                      </IonItem>
                    </IonCol>
                  </IonRow>

                  <IonRow>
                    <IonCol size="12" sizeMd="6">
                      <IonItem>
                        <IonLabel position="stacked">Requested Date</IonLabel>
                        <IonInput 
                          name="requestedDate"
                          type="date"
                          value={formData.requestedDate}
                          onIonChange={handleChange}
                          required
                        ></IonInput>
                      </IonItem>
                    </IonCol>
                    <IonCol size="12" sizeMd="6">
                      <IonItem>
                        <IonLabel position="stacked">Requested Time</IonLabel>
                        <IonInput 
                          name="requestedTime"
                          placeholder="e.g., 9:00 - 6:00"
                          value={formData.requestedTime}
                          onIonChange={handleChange}
                          required
                        ></IonInput>
                      </IonItem>
                    </IonCol>
                  </IonRow>

                  <IonRow>
                    <IonCol>
                      <IonItem>
                        <IonLabel position="stacked">Reason for Change of Schedule</IonLabel>
                        <IonTextarea 
                          name="reason"
                          value={formData.reason}
                          onIonChange={handleChange}
                          required
                          rows={4}
                        ></IonTextarea>
                      </IonItem>
                    </IonCol>
                  </IonRow>

                  <IonRow>
                    <IonCol size="12" sizeMd="4">
                      <IonItem>
                        <IonLabel position="stacked">Approved by (Immediate Superior)</IonLabel>
                        <IonInput 
                          name="approvedBy"
                          value={formData.approvedBy}
                          onIonChange={handleChange}
                        ></IonInput>
                      </IonItem>
                    </IonCol>
                    <IonCol size="12" sizeMd="4">
                      <IonItem>
                        <IonLabel position="stacked">Received by (HRO)</IonLabel>
                        <IonInput 
                          name="receivedBy"
                          value={formData.receivedBy}
                          onIonChange={handleChange}
                          disabled
                        ></IonInput>
                      </IonItem>
                    </IonCol>
                    <IonCol size="12" sizeMd="4">
                      <IonItem>
                        <IonLabel position="stacked">Date Received</IonLabel>
                        <IonInput 
                          name="dateReceived"
                          type="date"
                          value={formData.dateReceived}
                          onIonChange={handleChange}
                          disabled
                        ></IonInput>
                      </IonItem>
                    </IonCol>
                  </IonRow>
                </IonGrid>

                <div className="ion-padding">
                  <IonButton expand="block" disabled={isLoading} onClick={handleSubmit}>
                    {isLoading ? "Submitting..." : "Submit Request"}
                  </IonButton>
                  <IonButton expand="block" fill="outline" onClick={() => history.push("/dashboard")}>
                    Cancel
                  </IonButton>
                </div>
              </form>
            </IonCardContent>
          </IonCard>
        </IonContent>
      </IonPage>
    </>
  )
}

