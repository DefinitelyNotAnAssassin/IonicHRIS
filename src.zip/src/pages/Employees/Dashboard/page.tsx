"use client"

import { useEffect } from "react"
import {
  IonContent,
  IonPage,
  IonHeader,
  IonToolbar,
  IonTitle,
  IonButtons,
  IonMenuButton,
  IonCard,
  IonCardHeader,
  IonCardTitle,
  IonCardContent,
  IonGrid,
  IonRow,
  IonCol,
} from "@ionic/react"
import { useHistory } from "react-router-dom"
import { useAuth } from "@/hooks/use-auth"
import { FileText, Calendar, User, Clock, FileSpreadsheet } from "lucide-react"
import SideMenu from "@/components/side-menu"

export default function Dashboard() {
  const { user, isAuthenticated } = useAuth()
  const history = useHistory()

  useEffect(() => {
    if (!isAuthenticated) {
      history.push("/login")
    }
  }, [isAuthenticated, history])

  const navigateTo = (path: string) => {
    history.push(path)
  }

  return (
    <>
      <SideMenu />
      <IonPage id="main-content">
        <IonHeader className="shadow-sm">
          <IonToolbar className="bg-white">
            <IonButtons slot="start">
              <IonMenuButton></IonMenuButton>
            </IonButtons>
            <IonTitle className="font-semibold text-gray-800">Dashboard</IonTitle>
          </IonToolbar>
        </IonHeader>
        <IonContent className="ion-padding bg-gray-50">
          <div className="p-4 md:p-6">
            <div className="bg-gradient-to-r from-blue-500 to-indigo-600 rounded-lg shadow-md p-6 mb-8">
              <h1 className="text-2xl md:text-3xl font-bold text-white mb-2">
                Welcome, {user?.name || "User"}
              </h1>
              <p className="text-blue-100">Access your employee dashboard tools below</p>
            </div>

            <IonGrid>
              <IonRow>
                <IonCol size="12" sizeMd="6" sizeLg="4" className="mb-4">
                  <IonCard 
                    onClick={() => navigateTo("/personal-info")}
                    className="cursor-pointer rounded-xl overflow-hidden transform transition-all duration-300 hover:shadow-xl hover:scale-105 border-t-4 border-indigo-500"
                  >
                    <IonCardHeader className="bg-white">
                      <IonCardTitle className="flex items-center text-lg font-semibold text-gray-800">
                        <User className="mr-3 h-6 w-6 text-indigo-500" />
                        Personal Information
                      </IonCardTitle>
                    </IonCardHeader>
                    <IonCardContent className="py-4 text-gray-600">
                      <p>View and update your personal information</p>
                      <div className="mt-4 text-sm text-indigo-600 flex items-center">
                        <span>Access now</span>
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 ml-1" viewBox="0 0 20 20" fill="currentColor">
                          <path fillRule="evenodd" d="M12.293 5.293a1 1 0 011.414 0l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414-1.414L14.586 11H3a1 1 0 110-2h11.586l-2.293-2.293a1 1 0 010-1.414z" clipRule="evenodd" />
                        </svg>
                      </div>
                    </IonCardContent>
                  </IonCard>
                </IonCol>

                <IonCol size="12" sizeMd="6" sizeLg="4" className="mb-4">
                  <IonCard
                    onClick={() => navigateTo("/official-business")}
                    className="cursor-pointer rounded-xl overflow-hidden transform transition-all duration-300 hover:shadow-xl hover:scale-105 border-t-4 border-green-500"
                  >
                    <IonCardHeader className="bg-white">
                      <IonCardTitle className="flex items-center text-lg font-semibold text-gray-800">
                        <FileText className="mr-3 h-6 w-6 text-green-500" />
                        Official Business Form
                      </IonCardTitle>
                    </IonCardHeader>
                    <IonCardContent className="py-4 text-gray-600">
                      <p>Submit official business requests</p>
                      <div className="mt-4 text-sm text-green-600 flex items-center">
                        <span>Access now</span>
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 ml-1" viewBox="0 0 20 20" fill="currentColor">
                          <path fillRule="evenodd" d="M12.293 5.293a1 1 0 011.414 0l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414-1.414L14.586 11H3a1 1 0 110-2h11.586l-2.293-2.293a1 1 0 010-1.414z" clipRule="evenodd" />
                        </svg>
                      </div>
                    </IonCardContent>
                  </IonCard>
                </IonCol>

                <IonCol size="12" sizeMd="6" sizeLg="4" className="mb-4">
                  <IonCard
                    onClick={() => navigateTo("/change-schedule")}
                    className="cursor-pointer rounded-xl overflow-hidden transform transition-all duration-300 hover:shadow-xl hover:scale-105 border-t-4 border-amber-500"
                  >
                    <IonCardHeader className="bg-white">
                      <IonCardTitle className="flex items-center text-lg font-semibold text-gray-800">
                        <Calendar className="mr-3 h-6 w-6 text-amber-500" />
                        Change of Schedule
                      </IonCardTitle>
                    </IonCardHeader>
                    <IonCardContent className="py-4 text-gray-600">
                      <p>Request changes to your work schedule</p>
                      <div className="mt-4 text-sm text-amber-600 flex items-center">
                        <span>Access now</span>
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 ml-1" viewBox="0 0 20 20" fill="currentColor">
                          <path fillRule="evenodd" d="M12.293 5.293a1 1 0 011.414 0l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414-1.414L14.586 11H3a1 1 0 110-2h11.586l-2.293-2.293a1 1 0 010-1.414z" clipRule="evenodd" />
                        </svg>
                      </div>
                    </IonCardContent>
                  </IonCard>
                </IonCol>

                <IonCol size="12" sizeMd="6" sizeLg="4" className="mb-4">
                  <IonCard 
                    onClick={() => navigateTo("/attendance")}
                    className="cursor-pointer rounded-xl overflow-hidden transform transition-all duration-300 hover:shadow-xl hover:scale-105 border-t-4 border-purple-500"
                  >
                    <IonCardHeader className="bg-white">
                      <IonCardTitle className="flex items-center text-lg font-semibold text-gray-800">
                        <Clock className="mr-3 h-6 w-6 text-purple-500" />
                        Attendance
                      </IonCardTitle>
                    </IonCardHeader>
                    <IonCardContent className="py-4 text-gray-600">
                      <p>View your attendance records</p>
                      <div className="mt-4 text-sm text-purple-600 flex items-center">
                        <span>Access now</span>
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 ml-1" viewBox="0 0 20 20" fill="currentColor">
                          <path fillRule="evenodd" d="M12.293 5.293a1 1 0 011.414 0l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414-1.414L14.586 11H3a1 1 0 110-2h11.586l-2.293-2.293a1 1 0 010-1.414z" clipRule="evenodd" />
                        </svg>
                      </div>
                    </IonCardContent>
                  </IonCard>
                </IonCol>

                <IonCol size="12" sizeMd="6" sizeLg="4" className="mb-4">
                  <IonCard 
                    onClick={() => navigateTo("/reports")}
                    className="cursor-pointer rounded-xl overflow-hidden transform transition-all duration-300 hover:shadow-xl hover:scale-105 border-t-4 border-rose-500"
                  >
                    <IonCardHeader className="bg-white">
                      <IonCardTitle className="flex items-center text-lg font-semibold text-gray-800">
                        <FileSpreadsheet className="mr-3 h-6 w-6 text-rose-500" />
                        Reports
                      </IonCardTitle>
                    </IonCardHeader>
                    <IonCardContent className="py-4 text-gray-600">
                      <p>Access and generate reports</p>
                      <div className="mt-4 text-sm text-rose-600 flex items-center">
                        <span>Access now</span>
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 ml-1" viewBox="0 0 20 20" fill="currentColor">
                          <path fillRule="evenodd" d="M12.293 5.293a1 1 0 011.414 0l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414-1.414L14.586 11H3a1 1 0 110-2h11.586l-2.293-2.293a1 1 0 010-1.414z" clipRule="evenodd" />
                        </svg>
                      </div>
                    </IonCardContent>
                  </IonCard>
                </IonCol>
              </IonRow>
            </IonGrid>
          </div>
        </IonContent>
      </IonPage>
    </>
  )
}

